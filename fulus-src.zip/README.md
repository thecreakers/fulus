RPC Port: 42617
Network Port: 42618
#!/bin/bash
# create multiresolution windows icon
ICON_DST=../../src/qt/res/icons/Fulus.ico

convert ../../src/qt/res/icons/Fulus-16.png ../../src/qt/res/icons/Fulus-32.png ../../src/qt/res/icons/Fulus-48.png ${ICON_DST}
